package dao;

import dto.Board;

public interface BoardDAO {
	void insertDAO(Board board) throws Exception;
}
