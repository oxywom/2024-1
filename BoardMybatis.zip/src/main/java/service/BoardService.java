package service;

import dto.Board;

public interface BoardService {
	void boardWrite(Board board) throws Exception;
}
