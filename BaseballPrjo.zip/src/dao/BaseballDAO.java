package dao;

import java.io.FileInputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import dto.Player;
import dto.Team;

public class BaseballDAO {
	public static Connection getConnection() {
		Connection conn = null;
		try {
			Properties db = new Properties();
			db.load(new FileInputStream("db.properties"));
			Class.forName(db.getProperty("driver"));
			conn=DriverManager.getConnection(db.getProperty("url"),
					db.getProperty("user"),
					db.getProperty("password"));
		} catch(Exception e) {
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void close(Connection conn) {
		try {
			if(conn!=null) conn.close();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public static boolean insertTeam(Team team) {
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		String sql = "insert into team (name,loc) values (?,?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, team.getName());
			pstmt.setString(2, team.getLoc());
			pstmt.executeUpdate();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			
			close(conn);
		}
	}
	
	public static Team selectTeam(String name) {
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rset = null;	
		String sql = "select * from team where name like ?";
		Team team = null;
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, "%"+name+"%");
			rset = pstmt.executeQuery();
			if(rset!=null && rset.next()) {
				int rnum = rset.getInt(1);
				String rname = rset.getString(2);
				String rloc = rset.getString(3);
				team = new Team(rnum,rname,rloc);
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rset!=null) rset.close();
				if(pstmt!=null) pstmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			close(conn);
		}
		return team;
	}
	
	public static List<Team> selectTeamList() {
		Connection conn = getConnection();
		Statement stmt = null;
		ResultSet rset = null;
		List<Team> teamList = new ArrayList<>();
		String sql = "select * from team"; 
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(sql);
			if(rset!=null) {
				while(rset.next()) {
					int num = rset.getInt("num");
					String name = rset.getString("name");
					String loc = rset.getString("loc");
					teamList.add(new Team(num,name,loc));
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rset!=null) rset.close();
				if(stmt!=null) stmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			close(conn);
		}
		return teamList;
	}
	public static boolean insertPlayer(Player player) {
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		String sql = "insert into player (name,backnum,tnum) values (?,?,?)";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, player.getName());
			pstmt.setInt(2, player.getBacknum());
			pstmt.setInt(3, player.getTnum());
			pstmt.executeUpdate();
			return true;
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		} finally {
			try {
				if(pstmt!=null) pstmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			close(conn);
		}
	}
	
	public static List<Player> selectPlayer(String name) {
		Connection conn = getConnection();
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		List<Player> playList = new ArrayList<>();
		String sql= "SELECT p.*, t.name FROM player p JOIN team t ON p.tnum=t.num WHERE p.name=?";
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			rset = pstmt.executeQuery();
			if(rset!=null) {
				while(rset.next()) {
					int num = rset.getInt(1);
					String pname = rset.getString(2);
					int backnum = rset.getInt(3);
					int tnum = rset.getInt(4);
					String tname = rset.getString(5);
					playList.add(new Player(num, pname, backnum, tnum, tname));
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rset!=null) rset.close();
				if(pstmt!=null) pstmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			close(conn);
		}
		
		return playList;
	}
	
	public static List<Player> selectPlayerList() {
		Connection conn = getConnection();
		Statement stmt = null;
		ResultSet rset = null;
		List<Player> playList = new ArrayList<>();
		String sql= "SELECT p.*, t.name FROM player p JOIN team t ON p.tnum=t.num";
		try {
			stmt = conn.createStatement();
			rset = stmt.executeQuery(sql);
			if(rset!=null) {
				while(rset.next()) {
					int num = rset.getInt(1);
					String pname = rset.getString(2);
					int backnum = rset.getInt(3);
					int tnum = rset.getInt(4);
					String tname = rset.getString(5);
					playList.add(new Player(num, pname, backnum, tnum, tname));
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rset!=null) rset.close();
				if(stmt!=null) stmt.close();
			} catch(Exception e) {
				e.printStackTrace();
			}
			close(conn);
		}		
		return playList;
	}
}











