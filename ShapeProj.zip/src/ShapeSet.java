import shape.Shape;

public class ShapeSet {
	Shape[] shapes=new Shape[100];
	int count;

	public void addShape(Shape shape) {
		shapes[count++] = shape;
	}
	
	public void drawAllShapes() {
		for(int i=0; i<count; i++) {
			shapes[i].draw();
		}
	}
	
}
