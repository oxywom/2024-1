package shape;

abstract public class Shape {
	String color;
	public Shape() {
		this("��ȸ��"); 
	}
	public Shape(String color) {
		this.color=color;
	}
	
	abstract public void draw();
}