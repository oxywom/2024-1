package shape;

public class Circle extends Shape {
	Point center;
	int radius;
	public Circle() {}
	public Circle(String color, int x, int y, int raduis) {
		super(color);
		center = new Point(x,y);
		this.radius = raduis;
	}
	public Circle(String color, Point center, int radius) {
		super(color);
		this.center = center;
		this.radius = radius;
	}
	@Override
	public void draw() {
		System.out.println(String.format("[��-��:%s,�߽���:%s,������:%d]", color,center,radius));
	}
}
