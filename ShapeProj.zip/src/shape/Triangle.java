package shape;

public class Triangle extends Shape {
	Point pos1;
	Point pos2;
	Point pos3;
	
	public Triangle(String color, int x1,int y1, int x2, int y2, int x3, int y3) {
		super(color);
		pos1 = new Point(x1,y1);
		pos2 = new Point(x2,y2);
		pos3 = new Point(x3,y3);
	}
	
	public Triangle(String color, Point p1, Point p2, Point p3) {
		pos1 = p1;
		pos2 = p2;
		pos3 = p3;
	}
	@Override
	public void draw() {
		System.out.println(String.format("[�ﰢ��-��:%s,��1:%s,��2:%s,��3:%s]", 
				color,pos1,pos2,pos3));
	}
}
