package shape;

public class Rectangle extends Shape {
	Point startPos;
	int width;
	int height;
	
	public Rectangle(String color, int x, int y, int width, int height) {
		super(color);
		startPos = new Point(x,y);
		this.width=width;
		this.height=height;
	}
	
	public Rectangle(String color, Point startPos, int width, int height) {
		super(color);
		this.startPos=startPos;
		this.width=width;
		this.height=height;
	}
	
	@Override
	public void draw() {
		System.out.println(String.format("[�簢��-��:%s,������:%s,����:%d,����:%d]",
				color,startPos,width,height));
	}
}
