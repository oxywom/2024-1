public class AirUnit extends Unit {
	AirUnit(int hp) {
		super(hp);
	}
}