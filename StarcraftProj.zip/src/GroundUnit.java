public class GroundUnit extends Unit {
	public GroundUnit(int hp) {
		super(hp);
	}
}
